<?php

namespace App\Model\Staff;

use Illuminate\Database\Eloquent\Model;

class DesignationSalaryModel extends Model
{
    //
    protected $table = 'designation_salary_view';
}
