<?php

namespace App\Model\Staff;

use Illuminate\Database\Eloquent\Model;

class StaffModel extends Model
{
    //
    protected $table = 'staff_view';
    
}
