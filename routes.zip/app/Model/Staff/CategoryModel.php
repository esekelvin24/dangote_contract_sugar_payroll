<?php

namespace App\Model\Staff;

use Illuminate\Database\Eloquent\Model;

class CategoryModel extends Model
{
    //
    protected $table = "category";
    protected $primaryKey = "category_id";
}
