<?php

namespace App\Model\Staff;

use Illuminate\Database\Eloquent\Model;

class PayrollHistoryLogModel extends Model
{
    //
    protected $table = 'payroll_creation';
}
