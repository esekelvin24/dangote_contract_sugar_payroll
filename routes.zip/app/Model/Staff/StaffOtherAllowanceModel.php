<?php

namespace App\Model\Staff;

use Illuminate\Database\Eloquent\Model;

class StaffOtherAllowanceModel extends Model
{
    //
    protected $table = 'staff_other_allowance_view';
}
