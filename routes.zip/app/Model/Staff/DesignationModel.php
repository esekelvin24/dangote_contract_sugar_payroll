<?php

namespace App\Model\Staff;

use Illuminate\Database\Eloquent\Model;

class DesignationModel extends Model
{
    //
    //protected $table = "designation";
    //protected $primaryKey = "designation_id";
    
    protected $table = 'designation_view';
}
