<?php

namespace App\Model\Staff;

use Illuminate\Database\Eloquent\Model;

class DepartmentModel extends Model
{
    //
    protected $table = "department";
    
}
