<?php

namespace App\Model\Staff;

use Illuminate\Database\Eloquent\Model;

class TimeSheetModel extends Model
{
    //
    protected $table = 'time_sheet_view';
}
