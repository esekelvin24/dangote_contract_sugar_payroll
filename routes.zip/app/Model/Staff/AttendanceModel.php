<?php

namespace App\Model\Staff;

use Illuminate\Database\Eloquent\Model;

class AttendanceModel extends Model
{
    //
    protected $table = "time_sheet_attendance_view";
}
