<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Parameter extends Model
{
    //
    protected $table = "parameter";
}
