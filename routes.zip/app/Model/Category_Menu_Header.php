<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Category_Menu_Header extends Model
{
    //
    protected $table = 'menu_category_header'; 
    protected $primaryKey = 'id';
}
