<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class IMEI extends Model
{
    //
    protected $table = "imei";
    protected $primaryKey = "imei_no";
}
